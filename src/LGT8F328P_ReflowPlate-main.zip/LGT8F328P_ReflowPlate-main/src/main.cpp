/*
******************************************
* Hotplate Reflow Soldering Controller   *
******************************************
* v0.0 - Initial version by Massimo Divito
* v0.1 - English translation by Roland van Dalen
* v1.0 - Migrated to VS Code and PlatformIO
*        Added rotary encoder support using the Rotary library
*        Improved PID control for reflow and preheating
*        Added active cooling with fan control
*        Added RGB LED status indication
*        Added thermocouple fault detection
*        Added LOW TEMP profile – for SN42Bi58 low-temperature solder paste (melting point approximately 138 °C).
*        Replaced the passive buzzer with an active buzzer.
******************************************
* The profile has the following key targets:
* - Preheat: gradually warm the PCB.
* - Soak 1: allow the PCB and components to equalize in temperature.
* - Soak 2: bring the assembly closer to the melting point.
* - Reflow: reach a peak of approximately.
* - Cooling: cool in a controlled manner.
*/

// ================================================================
// LIBRARIES
// ================================================================
#include <Arduino.h>
#include <U8x8lib.h>
#include <Rotary.h> //https://github.com/buxtronix/arduino/tree/master/libraries/Rotary

#ifdef U8X8_HAVE_HW_SPI
#include <SPI.h>
#endif

#ifdef U8X8_HAVE_HW_I2C
#include <Wire.h>
#endif

#include <MAX6675_Thermocouple.h>
#include <PID_v1.h>
#include <FastPwmPin.h>

// ================================================================
// FUNCTION DECLARATIONS
// ================================================================
// --- Sound and feedback ------------------------------------------
void beep();
void longBeep();
void endBeep();
void encoderBeep();

// --- Reflow and preheater control --------------------------------
void reflowStart();
void reflowStop();
void reflowEnd();
void preheaterStart();
void preheaterStop();

// --- Temperature measurement and heater control ------------------
void readThermocouple();
void checkThermocouple();
void controlHeater();
void analogWrite2(int value);

// --- Display ------------------------------------------------------
void displayClear();
void displayError();
void displayRefresh();
void displayTemp();

// --- Fan and cooling ---------------------------------------------
void fanOn();
void fanOff();
void startActiveCooling();

// --- Status indicators -------------------------------------------
void RGB_LED(byte color);

// ================================================================
// HARDWARE CONFIGURATION
// ================================================================

// --- Thermocouple (MAX6675) --------------------------------------
#define SCK_PIN 8   // definition of the pins used
#define CS_PIN 9    // for reading the Type-K thermocouple
#define S0_PIN 11   // via the MAX6675

// --- User interface ----------------------------------------------
#define BUTTON_PIN  7 // Button of the rotary encoder
#define BUZZER_PIN 13 // Piezo buzzer
#define RE_DT_PIN 2  // Rotary encoder signal DT (encoder output A)
#define RE_CLK_PIN 4  // Rotary encoder signal CLK (encoder output B)

// --- Button logic -------------------------------------------------
#define BUTTON_PRESSED      HIGH
#define BUTTON_RELEASED     LOW

// --- Outputs ------------------------------------------------------
#define HOTPLATE_PIN 10 // Solid-state relay for the hotplate
#define FAN_PIN A3 //Cooler Fan | Correnponds to D17 internally

// --- RGB status LED ----------------------------------------------

#define BLUE_LED A0 //RGB-LED Blue pin
#define GREEN_LED A1 //RGB-LED Green pin
#define RED_LED A2 //RGB-LED Red pin


// --- Rotary encoder ----------------------------------------------
//Swap OUTPUTA and OUTPUTB to change the RotaryEncoder direction
#define ENCODER_A RE_CLK_PIN //... also known as
#define ENCODER_B RE_DT_PIN //... also known as

// ================================================================
// HARDWARE OBJECTS AND GRAPHICS
// ================================================================

// --- Rotary encoder ----------------------------------------------
// The Rotary encoder is wired with the common to ground and the two outputs to pins ENCODER_A and ENCODER_B.
Rotary rotary = Rotary(ENCODER_A, ENCODER_B);

// --- Thermocouple -------------------------------------------------
MAX6675_Thermocouple tc = MAX6675_Thermocouple(SCK_PIN, CS_PIN, S0_PIN);

// --- OLED display -------------------------------------------------
//SCL and SDA are predefined by the Arduino board's variant definitions | for Nano and LGT8F328P; SCL → A5 / SDA → A4
U8X8_SSD1306_128X64_NONAME_SW_I2C oled(/* clock=*/ SCL, /* data=*/ SDA, /* reset=*/ U8X8_PIN_NONE);   // OLEDs without Reset of the Display 

// --- Thermometer icon --------------------------------------------
uint8_t thermometerUP[8] = {0x00, 0x00, 0xFE, 0xC1, 0xC1, 0x7E, 0x00, 0x00}; //upper part of the thermometer icon
uint8_t thermometerDWN[8] = {0x3C, 0x7E, 0xFF, 0xFF, 0xFF, 0xFF, 0x7E, 0x3C}; //lower part of the thermometer icon

// ================================================================
// REFLOW PROFILES AND PROCESS SETTINGS
// ================================================================

// --- Preheater temperature settings ------------------------------
#define TEMPAMBIENT 25 //ambient temperature in degree Celsius
int tempMinPreheater = 60 ; //set the minimum selectable preheater temperature
int tempMaxPreheater = 250; //set the maximum selectable preheater temperature
int tempStepPreheater = 5; //set the preheater temperature adjustment step

// --- Startup safety limit and temperature adjustment -------------
int maxStartupTemperature = 50; //maximum allowed plate temperature at startup; reflow cannot start if the plate is hotter
int tempAdjust = 0; //correction applied to the temperature read by the thermocouple

// --- Soldering profiles ------------------------------------------
int profiles [2][6][2] = {  
  //{{0, TEMPAMBIENT}, {30, 150}, {60, 150}, {90, 225}, {120, 225}, {150, 0}},  // FOR TESTING ONLY: leaded solder profile with shorter times
  {{0, TEMPAMBIENT}, {60, 100}, {120, 100}, {180, 130}, {240, 165}, {300, 80}}, // SN42Bi58 low-temperature solder paste
  {{0, TEMPAMBIENT}, {60, 150}, {180, 150}, {240, 225}, {260, 225}, {380, 0}},  // leaded solder profile
  //{{0, TEMPAMBIENT}, {60, 150}, {180, 180}, {240, 255}, {255, 255}, {320, 0}}   // lead-free solder profile
};

const char *profilesNames[] = {
  "LOW TEMP",
  "LEADED",
  "PREHEATER"
};

// --- Profile phase labels ----------------------------------------
const char *phases[] = {
  "Preheat",
  "Soak 1 ",
  "Soak 2 ",
  "Reflow ",
  "Cooling"
};

// ================================================================
// GLOBAL VARIABLES AND PROCESS STATE
// ================================================================

// --- User interface state ----------------------------------------
bool buttonState, previousButtonState;
bool longPressHandled = false;
int profile = 0;

// --- Heating process state ---------------------------------------
bool reflowRunning = false;
bool preheaterRunning = false;
int tempTarget, tempRead;
int tempPreheater;

// --- Active cooling state ----------------------------------------
bool activeCooling = false;
bool coolingFanStarted = false;
bool coolingFanStopped = false;


// --- Thermocouple fault monitoring -------------------------------
const unsigned long thermocoupleFaultTimeout = 3000; // 3 seconds
unsigned long thermocoupleZeroStart = 0;
bool thermocoupleFault = false;

// --- RGB LED colors ----------------------------------------------
enum LedColor : byte {
  LED_OFF = 0,
  R = 1,
  G = 2,
  B = 4
};

// ================================================================
// TIMERS AND PID CONTROLLER
// ================================================================

// --- Timing -------------------------------------------------------
long secondInMillis = 1000;

unsigned long timer1, deltaTimer1; // Reflow process
unsigned long reflowStartTime; 
unsigned long timer2, deltaTimer2;  // Button handling
unsigned long timer3, deltaTimer3;  // Preheater process
unsigned long timer4, deltaTimer4;  // Display refresh



// --- Reflow profile interpolation -------------------------------
long reflowNowTime, xa, xb; //long variables for the linear interpolation function
int ya, yb; //int variables for the linear interpolation function
int currentPhase;

// --- PID controller ----------------------------------------------
double Setpoint, Input, Output; //Variables used by the PID controller

//double reKp = 8, reKi = 0.025 , reKd = 8; //reflow PID values
//double reKp = 8, reKi = 0.025 , reKd = 4; //reflow PID values
//double reKp = 4, reKi = 0.010, reKd = 4; //reflow PID values
double reKp = 3, reKi = 0.005, reKd = 4; //reflow PID values
//double preKp = 3, preKi = 0.025 , preKd = 20; //preheater PID values
double preKp = 3, preKi = 0.025, preKd = 2; //temporarily

PID myPID(&Input, &Output, &Setpoint, reKp, reKi, reKd, DIRECT);

int WindowSize = 250;




void setup() {

  Serial.begin(115200); //set SerialMonitor to this baudrate - wrong reading means probally wrong Board selected; 16MHz instead of 32MHz
  // Wait for serial to initialise


  while (!Serial) {   }; //wait for serial - needed for the 32MHz LGT8F328P
  Serial.println();
  Serial.println("Starting up LGT8F328 board");
  Serial.println();

  pinMode(GREEN_LED, OUTPUT);  //  Green LED
  pinMode(RED_LED, OUTPUT);  //  Red LED
  pinMode(BLUE_LED, OUTPUT);  //  Blue LED
  RGB_LED(G); // Green LED on at startup | Hotplate Reflow Ready

  pinMode(HOTPLATE_PIN, OUTPUT);  //  Solid-state relay for the hotplate
  digitalWrite(HOTPLATE_PIN, LOW); // Hotplate off at startup
  pinMode(FAN_PIN, OUTPUT); // Cooler Fan
  digitalWrite(FAN_PIN, LOW); // Fan OFF at startup
  pinMode(ENCODER_A, INPUT_PULLUP); //set encoder pins as inputs and enable the internal pull-up resistors
  pinMode(ENCODER_B, INPUT_PULLUP); //set encoder pins as inputs and enable the internal pull-up resistors

  pinMode(BUTTON_PIN, INPUT); //START/STOP button
    //pinMode(BUTTON_PIN, INPUT_PULLUP); //START/STOP button and enable the internal pull-up resistors
  buttonState = (digitalRead(BUTTON_PIN) == BUTTON_PRESSED);
  previousButtonState = buttonState;

  pinMode(BUZZER_PIN, OUTPUT); //piezo buzzer
  FastPwmPin::enablePwmPin(HOTPLATE_PIN, 1L, 0);  //enable 1 Hz PWM on the heater output
  oled.begin(); //initialize the display
  displayRefresh(); //refresh the display
  //previousEncoderState = digitalRead(ENCODER_A_PIN); //read the encoder state
  timer1 = millis();  //initialize timer1
  timer3 = millis();  //initialize timer3
  timer4 = millis();  //initialize timer4  
  myPID.SetOutputLimits(0, 100);
  myPID.SetMode(MANUAL);
  readThermocouple();
  delay(1000); 
}

void loop() {

  // ================================================================
  // 1. THERMOCOUPLE FAULT MONITORING — EVERY 250 ms
  // ================================================================

  static unsigned long thermocoupleTimer = 0;

  if (millis() - thermocoupleTimer >= 250) {
    thermocoupleTimer = millis();

    if (reflowRunning || preheaterRunning) {
      checkThermocouple();
    }
  }
  
 // While a thermocouple fault is active, only handle the button
  if (thermocoupleFault) {
    buttonState = (digitalRead(BUTTON_PIN) == BUTTON_PRESSED);

    if (!previousButtonState && buttonState) {
      timer2 = millis();
      deltaTimer2 = 0;
      longPressHandled = false;
    }

    if (previousButtonState && buttonState && !longPressHandled) {
      deltaTimer2 = millis() - timer2;

      if (deltaTimer2 > 2000) {
        longPressHandled = true;
        Serial.println("Thermocouple fault acknowledged");

        thermocoupleFault = false;
        thermocoupleZeroStart = 0;

        displayClear();
        RGB_LED(G);
        beep();
      }
    }

    previousButtonState = buttonState;
    delay(50);
    return;
  }


  // ================================================================
  // 2. ROTARY ENCODER — PROFILE AND TEMPERATURE SELECTION
  // ================================================================

  // Process encoder transitions on every loop iteration.
  // The Rotary library decodes the quadrature signals.
  unsigned char encoderResult = rotary.process();

  if (!reflowRunning) {
    bool displayNeedsRefresh = false;

    if (encoderResult == DIR_CW) {
      encoderBeep();
      if (!preheaterRunning) {
        // Select the next reflow profile
        profile++;
        if (profile >= 3) profile = 0;
//        Serial.print("Rotary Encoder CW: profile "); Serial.println(profile);
        displayNeedsRefresh = true;
      } else {
        // Increase the preheater temperature
        if (tempPreheater <=
            (tempMaxPreheater - tempStepPreheater)) {
          tempPreheater += tempStepPreheater;
//         Serial.print("Rotary Encoder CW: tempPreheater "); Serial.println(tempPreheater);
          displayNeedsRefresh = true;
        }
      }
    } else if (encoderResult == DIR_CCW) {
        encoderBeep();
        if (!preheaterRunning) {
          // Select the previous reflow profile
          profile--;
          if (profile < 0) profile = 2;
//          Serial.print("Rotary Encoder CCW: profile "); Serial.println(profile);
          displayNeedsRefresh = true;
        } else {
          // Decrease the preheater temperature
          if (tempPreheater >=
              (tempMinPreheater + tempStepPreheater)) {
            tempPreheater -= tempStepPreheater;
//            Serial.print("Rotary Encoder CCW: tempPreheater "); Serial.println(tempPreheater);
            displayNeedsRefresh = true;
          }
        }
    }
    if (displayNeedsRefresh) {
      displayRefresh();
    }
  }


  // ================================================================
  // 3. BUTTON HANDLING — SHORT AND LONG PRESS
  // ================================================================

  // Read button
  buttonState = (digitalRead(BUTTON_PIN) == BUTTON_PRESSED);
  if (!previousButtonState && buttonState) { // when button is pressed
    Serial.println("Button Pressed");
    timer2 = millis();  //initialize timer2
    deltaTimer2 = 0;  //initialize deltaTimer2
    longPressHandled = false;
  }
  if (previousButtonState && buttonState && !longPressHandled) {     // Button held: handle long press only once
    deltaTimer2 = millis() - timer2;
    if (deltaTimer2 > 2000) {   //if it is held for more than 2 seconds...
      longPressHandled = true;
      Serial.println("Button LongPressed");
      if (reflowRunning) {  //.... if the reflow process is running, stop it
        reflowStop();  //Stop reflow
        delay(500);
      } else if (preheaterRunning) {  //.... if the preheating process is running, stop it
        preheaterStop();  //Stop preheating
        delay(500);
      } else if (activeCooling) {
        Serial.println("Active cooling manually stopped");
        activeCooling = false;
        fanOff();
        RGB_LED(G);
        displayClear();
        delay(500);
      }
    }
  }
  if (previousButtonState && !buttonState) {   //when button is released: handle short press
    if ((!longPressHandled && deltaTimer2 < 2000) && (!reflowRunning) && (!preheaterRunning)) {   //if released before 2 seconds and neither reflow nor preheating is running
      if ((profile < 2)) { //if a reflow profile has been selected…
        readThermocouple();
        if (tempRead < maxStartupTemperature) { //…if the hotplate is cool enough, start it
          reflowStart();
        } else {
          displayError();
        }
      } else { //otherwise, start the preheater function
        preheaterStart();
      }
    }
    // The next press can trigger another long press
    longPressHandled = false;
  }
  previousButtonState = buttonState;


  
  // ================================================================
  // 4. REFLOW PROCESS — PROFILE AND HEATER CONTROL
  // ================================================================

  deltaTimer1 = millis() - timer1;

  if ((deltaTimer1 >= 250) && (reflowRunning)) {  //every 250 ms
    reflowNowTime = (unsigned long)(millis() - reflowStartTime); // calculate how many milliseconds have elapsed since the reflow cycle started;
//    for (int i = 0; i < 6; i++) {
    for (int i = 0; i < 5; i++) {
      if ((reflowNowTime >= (profiles[profile][i][0] * secondInMillis)) && ( reflowNowTime < (profiles[profile][i + 1][0] * secondInMillis))) {
        xa = profiles[profile][i][0] * secondInMillis;
        xb = profiles[profile][i + 1][0] * secondInMillis;
        ya = profiles[profile][i][1];
        yb = profiles[profile][i + 1][1];

        tempTarget = ((((reflowNowTime - xa) * (yb - ya)) / (xb - xa))) + ya;
        // y0=( ( (x0-xa)*(yb-ya) ) / (xb-xa) ) + ya   linear interpolation formula

        currentPhase = i;
        controlHeater();

        // Cooling phase: phase index 4
        if (currentPhase == 4) {

          // Switch the fan on when Cooling starts
          if (!coolingFanStarted) {            
            fanOn();
            coolingFanStarted = true;
            Serial.println("Cooling phase: fan ON");
          }

        }
      }
    }
    if (reflowNowTime > (profiles[profile][5][0] * secondInMillis)) {   //if the final profile time has been exceeded, stop the process
      reflowEnd();
    }
    timer1 = millis();
  }

  // ================================================================
  // 5. ACTIVE COOLING — TEMPERATURE AND FAN CONTROL
  // ================================================================

  if (activeCooling) {
    unsigned long now = millis();

    if (now - timer4 >= 500) {   // Refresh the display every half second during active cooling
      timer4 = now;
      readThermocouple();
      displayTemp();
    }

    if (tempRead < maxStartupTemperature) {
      Serial.println("End of Active cooling phase: fan OFF"); 
      activeCooling = false;
      fanOff();
      displayClear();
      RGB_LED(G); // Green LED on | Hotplate Reflow Ready
      beep(); delay(100); beep();
    }
  }


  // ================================================================
  // 6. PREHEATER PROCESS — TEMPERATURE CONTROL
  // ================================================================

  deltaTimer3 = millis() - timer3;

  if ((deltaTimer3 >= 250) && (preheaterRunning)) {  //every 250 ms
    tempTarget = tempPreheater;
    controlHeater();
    timer3 = millis();
  }

  // ================================================================
  // 7. DISPLAY UPDATE — RUNNING PROCESSES
  // ================================================================

  deltaTimer4 = millis() - timer4;

  if ((deltaTimer4 >= 500) && (preheaterRunning || reflowRunning ))  {
    displayRefresh();
    timer4 = millis();
  }

}

// ================================================================
// FUNCTIONS
// ================================================================

// ================================================================
// SOUND AND FEEDBACK
// ================================================================

/*
// For passive buzzers, the following functions are used:
void beep() {
  tone(BUZZER_PIN, 1000, 100);
  delay(100);
}

void longBeep() {
  tone(BUZZER_PIN, 1000, 1000);
  delay(100);
}

void endBeep() {
  tone(BUZZER_PIN, 1000, 100);
  delay(1000);
  tone(BUZZER_PIN, 1000, 100);
  delay(1000);
  tone(BUZZER_PIN, 1000, 1000);
  delay(100);
}
*/
//For an active buzzer, the following functions are used:
// Short beep
void beep() {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(100);
  digitalWrite(BUZZER_PIN, LOW);
}

// Long beep
void longBeep() {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(1000);
  digitalWrite(BUZZER_PIN, LOW);
}

// End-of-process beep pattern: short, short, long
void endBeep() {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(100);
  digitalWrite(BUZZER_PIN, LOW);
  delay(1000);

  digitalWrite(BUZZER_PIN, HIGH);
  delay(100);
  digitalWrite(BUZZER_PIN, LOW);
  delay(1000);

  digitalWrite(BUZZER_PIN, HIGH);
  delay(1000);
  digitalWrite(BUZZER_PIN, LOW);
}

void encoderBeep() {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(10);
  digitalWrite(BUZZER_PIN, LOW);
}

// ================================================================
// REFLOW AND PREHEATER CONTROL
// ================================================================

void reflowStart() {
  Serial.println("Hotplate Reflow process running");
  reflowRunning = true;
  reflowStartTime = millis();
  thermocoupleFault = false;
  thermocoupleZeroStart = 0;
  activeCooling = false;
  coolingFanStarted = false;
  coolingFanStopped = false;
  fanOff();
  myPID.SetTunings(reKp, reKi, reKd);
  myPID.SetMode(AUTOMATIC);  //enable the PID controller
  beep();
  displayClear();
}

void reflowStop() {
  Serial.println("Hotplate Reflow process interrupted");
  reflowRunning = false;
  myPID.SetMode(MANUAL);  //disable the PID controller
  analogWrite2(0); //turn off the heater
  coolingFanStarted = false;
  fanOff();
  longBeep();
//  displayClear();
  oled.clear();
  delay(100);
  startActiveCooling();
}

void reflowEnd() {
  Serial.println("Hotplate Reflow process ended");
  reflowRunning = false;
  myPID.SetMode(MANUAL);  //disable the PID controller
  analogWrite2(0); //turn off the heater
  coolingFanStarted = false;
  fanOff();
  endBeep();
//  displayClear();
  oled.clear();
  delay(100);
  startActiveCooling();
}

void preheaterStart() {
  Serial.println("Preheater started");
  preheaterRunning = true;
  thermocoupleFault = false;
  thermocoupleZeroStart = 0;
  activeCooling = false; //stop the fan if it is still cooling the plate
  fanOff();  
  tempPreheater = tempMinPreheater; //set the temperature to the minimum
  tempTarget = tempPreheater;   
  myPID.SetTunings(preKp, preKi, preKd); 
  myPID.SetMode(AUTOMATIC);  //enable the PID controller  
  controlHeater();
  beep();
  displayClear();
}

void preheaterStop() {
  Serial.println("Preheater stopped");
  preheaterRunning = false;
  myPID.SetMode(MANUAL);  //disable the PID controller
  analogWrite2(0);  // Heater OFF
  longBeep(); 
//  displayClear();
  oled.clear();
  delay(100);
  startActiveCooling();
}

// ================================================================
// TEMPERATURE MEASUREMENT AND HEATER CONTROL
// ================================================================

void readThermocouple() {
  tempRead = tc.readCelsius() + tempAdjust;
}

void checkThermocouple() {
  if (!reflowRunning && !preheaterRunning) {
    thermocoupleZeroStart = 0;
    return;
  }
  readThermocouple();
  //tempRead=21; //For Testing only | Remove this line in the final version
  if (tempRead == 0) {
    if (thermocoupleZeroStart == 0) {
      thermocoupleZeroStart = millis();
    } else if (millis() - thermocoupleZeroStart >= thermocoupleFaultTimeout) {
      thermocoupleFault = true;

      Serial.println("ERROR: Check Thermocouple");

      // Stop heating immediately
      reflowRunning = false;
      preheaterRunning = false;
      myPID.SetMode(MANUAL);
      analogWrite2(0);

      // Stop the fan so the error remains visible
      activeCooling = false;
      fanOff();
      RGB_LED(LED_OFF);

      oled.clear();
      oled.setFont(u8x8_font_amstrad_cpc_extended_f);
      oled.drawString(0, 2, "Check");
      oled.drawString(0, 4, "Thermocouple");

      longBeep();
    }
  } else {
    thermocoupleZeroStart = 0;
  }
}

void controlHeater() {
  readThermocouple();
  RGB_LED(R); // Red LED on | Hotplate Reflow process running
  Setpoint = tempTarget;
  Input = tempRead;  
  myPID.Compute();
/*
  Serial.print("Setpoint: ");
  Serial.print(Setpoint);
  Serial.print(" C | Input: ");
  Serial.print(Input);
  Serial.print(" C | Output: ");
  Serial.println(Output);
*/
  analogWrite2(Output);
}

void analogWrite2(int value) {
  static int previousValue = -1;
  value = constrain(value, 0, 100);
  if (value != previousValue) {
//    Serial.print("PWM value: ");
//    Serial.println(value);
    previousValue = value;
  }

  if (value == 0) {
    FastPwmPin::disablePwmPin(HOTPLATE_PIN, LOW);
  }
  else if (value == 100) {
    FastPwmPin::disablePwmPin(HOTPLATE_PIN, HIGH);
  }
  else {
    FastPwmPin::enablePwmPin(HOTPLATE_PIN, 1L, value);
  }
}


// ================================================================
// DISPLAY
// ================================================================

void displayClear() {
  oled.clear();
  delay(100);
  displayRefresh();
}

void displayError() {
  oled.clear();
  delay(100);
  char _str[5]; //variable used to format strings
  oled.setFont(u8x8_font_amstrad_cpc_extended_f);                        
  oled.drawString(0, 1, "  Temperature");
  oled.drawString(0, 2, "  too high");
  oled.drawTile(3, 5, 1, thermometerUP); //draw the upper part of the thermometer icon
  oled.drawTile(3, 6, 1, thermometerDWN); //draw the lower part of the thermometer icon
  sprintf(_str, "%3i\xb0", tempRead); //format the string as a three-digit integer and append the symbol "°"
  oled.draw2x2String(5, 5, _str);
  sprintf(_str, "%3i", (int)tempRead);
  longBeep();
  delay(4000);
//  displayClear();
  oled.clear();
  delay(100);
  startActiveCooling();
}


void displayRefresh() {
  if ((!reflowRunning) && (!preheaterRunning)) { //if neither reflow nor preheating is running, show the menu
    oled.setFont(u8x8_font_amstrad_cpc_extended_r);
    oled.inverse();
    oled.draw1x2String(0, 0, "Hotplate Reflow ");
    oled.noInverse();
    oled.drawString(1, 3, profilesNames[0]);
    oled.drawString(1, 5, profilesNames[1]);
    oled.drawString(1, 7, profilesNames[2]);
    oled.drawString(0, 3, (profile == 0 ? ">" : " ")); //if profile=0, display ">"; otherwise display a space
    oled.drawString(0, 5, (profile == 1 ? ">" : " ")); //if profile=1, display ">"; otherwise display a space
    oled.drawString(0, 7, (profile == 2 ? ">" : " ")); //if profile=2, display ">"; otherwise display a space
  }

  if (reflowRunning) {  //if reflow is running
    char _str[5]; //variable used to format strings
    oled.setFont(u8x8_font_amstrad_cpc_extended_f);
    oled.drawString(3, 0, profilesNames[profile]); //display the profile currently running
    oled.drawTile(1, 2, 1, thermometerUP); //draw the upper part of the thermometer icon
    oled.drawTile(1, 3, 1, thermometerDWN); //draw the lower part of the thermometer icon
    sprintf(_str, "%3i\xb0", tempTarget); //format the string as a three-digit integer and append the symbol "°"
    oled.draw2x2String(3, 2, _str);
    sprintf(_str, "%3i\xb0", tempRead); //format the string as a three-digit integer and append the symbol "°"
    oled.drawString(12, 2, _str);
    oled.drawString(1, 5, "Phase:");
    oled.drawString(8, 5, phases[currentPhase]);
    sprintf(_str, "%3i", (int)tempRead);
    oled.drawString(1, 7, "Time:");
    oled.drawString(11, 7, "/");
    sprintf(_str, "%3i", (int)(reflowNowTime / 1000));
    oled.drawString(8, 7, _str);
    sprintf(_str, "%3i", profiles[profile][5][0]);
    oled.drawString(12, 7, _str);
  }

  if (preheaterRunning) {  //if the preheater is running
    char _str[5]; //variable used to format strings
    oled.setFont(u8x8_font_amstrad_cpc_extended_f);
    oled.drawString(0, 1, profilesNames[2]);
    oled.drawTile(1, 4, 1, thermometerUP); //draw the upper part of the thermometer icon
    oled.drawTile(1, 5, 1, thermometerDWN); //draw the lower part of the thermometer icon
    sprintf(_str, "%3i\xb0", (int)tempPreheater); //format the string as a three-digit integer and append the symbol "°"
    oled.draw2x2String(3, 4, _str);
    sprintf(_str, "%3i\xb0", (int)tempRead); //format the string as a three-digit integer and append the symbol "°"
    oled.drawString(12, 4, _str);    
  }
}

void displayTemp() {
  //oled.clear();
  oled.setFont(u8x8_font_amstrad_cpc_extended_f);

  oled.drawString(0, 1, " Active Cooling");
  oled.drawString(0, 2, "     WAIT...");

  oled.drawTile(3, 5, 1, thermometerUP);
  oled.drawTile(3, 6, 1, thermometerDWN);

  char str[6];
  sprintf(str, "%3i\xb0", tempRead);
  oled.draw2x2String(5, 5, str);
}

// ================================================================
// FAN AND COOLING
// ================================================================

void fanOn() {
  digitalWrite(FAN_PIN, HIGH);
// Serial.println("Cooling phase: fan ON"); 
}

void fanOff() {
  digitalWrite(FAN_PIN, LOW);
// Serial.println("Cooling phase: fan OFF"); 
}


void startActiveCooling() {
  readThermocouple();

  if (tempRead < maxStartupTemperature) {
    // Plate is already cool enough
    activeCooling = false;
    fanOff();
    RGB_LED(G);
    displayClear();
    return;
  }

  // Plate is still hot: start active cooling
  activeCooling = true;
  Serial.println("Active cooling phase: fan ON"); 
  fanOn();
  RGB_LED(B);
  displayTemp();
  timer4 = millis();
}

// ================================================================
// STATUS INDICATORS
// ================================================================

void RGB_LED(byte color) {
/* Examples
RGB_LED(R);       // Red
RGB_LED(G);       // Green
RGB_LED(B);       // Blue

RGB_LED(R | G);   // Yellow
RGB_LED(R | B);   // Magenta
RGB_LED(G | B);   // Cyan
RGB_LED(R | G | B); // White (all LEDs on)

RGB_LED(0);       // All LEDs off
*/

  digitalWrite(RED_LED,   (color & R) ? HIGH : LOW);
  digitalWrite(GREEN_LED, (color & G) ? HIGH : LOW);
  digitalWrite(BLUE_LED,  (color & B) ? HIGH : LOW);
}
